# ObjectCountingFromCameraOrLiveImage
Object Counting From Camera or Live Image / Python - OpenCV 
Background Substraction
Unsharp Masking
