import cv2 as cv
import numpy as np

theImg = cv.imread('10.JPG')
theImg = cv.resize(theImg, (600, 480))
gray_img = cv.cvtColor(theImg, cv.COLOR_BGR2GRAY)

sift = cv.xfeatures2d.SIFT_create()
keypoints, descriptor = sift.detectAndCompute(gray_img, None)

theImg = cv.drawKeypoints(image=theImg, outImage=theImg, keypoints=keypoints,
                          flags=cv.DrawMatchesFlags_DRAW_RICH_KEYPOINTS, color= (0, 179, 60))

cv.imshow('Keypoints', theImg)
print(len(keypoints))
while(True):
    if cv.waitKey(1) & 0xFF == ord('q'):
        break
cv.destroyAllWindows()