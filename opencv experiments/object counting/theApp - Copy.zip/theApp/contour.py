import cv2 as cv
import numpy as np

theImg = cv.imread('10.JPG', 0)
theImg = cv.resize(theImg, (600, 600))

ret, thres = cv.threshold(theImg, 0, 255, cv.THRESH_BINARY+cv.THRESH_OTSU)
image, contours, hierarchy = cv.findContours(thres, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)

color_img = cv.cvtColor(theImg, cv.COLOR_GRAY2BGR)
theImg = cv.drawContours(color_img, contours, -1, (200, 0, 0), 1)
print("Number of detected contours: " + str(len(contours)))

cv.putText(color_img, "Number of detected contours: " + str(len(contours)), (10, 320), cv.FONT_HERSHEY_SIMPLEX, 1, (0, 200, 50), 1)

cv.imshow("Image with detected contours", color_img)
cv.waitKey()
cv.destroyAllWindows()