import cv2 as cv
import numpy as np

cap = cv.VideoCapture(0)

if (cap.isOpened()) == False:
    print('Unable to read camera feed')

while(True):
    ret, frame = cap.read()
    frame = cv.resize(frame, (600, 600))
    cv.imshow('The name of the window', frame)

    if cv.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv.destroyAllWindows()