import cv2
import numpy as np
import matplotlib.pyplot as plt
import sys
import imutils

from PyQt5 import QtWidgets, QtGui, QtCore
from PyQt5.QtCore import pyqtSignal, pyqtSlot, QThread, QTimer
from PyQt5.QtGui import QPixmap, QImage, QIcon
from PyQt5.QtWidgets import QMessageBox


class MainWindow:
    def __init__(self):
        self.app = QtWidgets.QApplication(sys.argv)
        self.window = QtWidgets.QMainWindow()

        self.window.setWindowTitle('The App for You!')
        self.window.setGeometry(300, 100, 815, 1000)
        self.window.setWindowIcon(QIcon('01.jpg'))
        self.window.setMaximumSize(815, 1000)

        self.window.show()
        sys.exit(self.app.exec_())


main = MainWindow()