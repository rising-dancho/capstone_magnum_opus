import cv2
import numpy as np

theImage = cv2.imread('usrprof.png')
gray_img = cv2.cvtColor(theImage, cv2.COLOR_BGR2GRAY)

cv2.imshow('The gray image', gray_img)
cv2.waitKey()
cv2.destroyAllWindows()