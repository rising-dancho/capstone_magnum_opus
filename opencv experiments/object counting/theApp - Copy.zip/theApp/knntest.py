import cv2 as cv
import numpy as np
from matplotlib import pyplot as plt

# creating the set of training dataset
trainData = np.random.randint(0, 100, (25, 2)).astype(np.float32)

#label
res = np.random.randint(0, 2, (25, 1)).astype(np.float32)

#plot red neighbours
red = trainData[res.ravel() == 0]
plt.scatter(red[:, 0], red[:, 1], 80, 'r', '*')

#plot blue neighbours
blue = trainData[res.ravel() == 1]
plt.scatter(blue[:, 0], blue[:, 1], 80, 'b', 's')

newItem = np.random.randint(0, 100, (1, 2)).astype(np.float32)
plt.scatter(newItem[:, 0], newItem[:, 1], 80, 'g', 'o')

knn = cv.ml.KNearest_create()
knn.train(trainData, cv.ml.ROW_SAMPLE, res)

ret, results, neighbours, dist = knn.findNearest(newItem, 3)
print('Result: {} \n'.format(results))
print('Neighours: {} \n'.format(neighbours))
print('Distance: {} \n'.format(dist))

plt.show()