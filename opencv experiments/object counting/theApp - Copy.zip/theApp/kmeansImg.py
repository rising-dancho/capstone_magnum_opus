import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt

img = cv.imread('nature.png')
img = cv.resize(img, (600, 480))

Z = img.reshape((-1, 3))

Z = np.float32(Z)

criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 10, 1.0)
k = 4
ret, label, center = cv.kmeans(Z, k, None, criteria, 10, cv.KMEANS_RANDOM_CENTERS)

center = np.uint8(center)
res = center[label.flatten()]
res2 = res.reshape((img.shape))

cv.imshow('Res 2', res2)
cv.waitKey(0)
cv.destroyAllWindows()