import cv2 as cv
import numpy as np

myImg = cv.imread('usrprof.png')

#draw line
cv.line(myImg, (0, 20), (230, 350), (200, 0, 50), 4)

#draw rectangle
cv.rectangle(myImg, (50, 50), (200, 200), (0, 200, 50), 3)

#draw circle
cv.circle(myImg, (100, 100), 60, (0, 50, 200), 5)

#write text
myFont = cv.FONT_HERSHEY_SIMPLEX
cv.putText(myImg, 'The text we want to add', (0, 350), myFont, 1, (0, 200, 200), 2)


cv.imshow("Diplaying our image", myImg)
theKey = cv.waitKey(0) & 0xFF
if theKey == ord('q'):
    cv.destroyAllWindows()
    print("Closed without saving")
elif theKey == ord('s'):
    saveMyImg = cv.imwrite('saveMe.png', myImg)
    cv.destroyAllWindows()
    print("Saved successful")
