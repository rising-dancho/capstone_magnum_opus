import cv2 as cv
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
import glob
import math

image = cv.imread('testImg13.JPG')

d = 1024 / image.shape[1]
dim = (1024, int(image.shape[0] * d))
image = cv.resize(image, dim, interpolation=cv.INTER_AREA)

output = image.copy()

#convert the image to grayscale
gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)

clahe = cv.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
gray = clahe.apply(gray)

#calculate the histogram
def calHistogram(img):
    m = np.zeros(img.shape[:2], dtype="uint8")
    (w, h) = (int(img.shape[1] / 2), int(img.shape[0] / 2))
    cv.circle(m, (w, h), 60, 255, -1)

    h = cv.calcHist([img], [0, 1, 2], m, [8, 8, 8], [0, 256, 0, 256, 0, 256])

    return cv.normalize(h, h).flatten()

def calcHistFromFile(file):
    img = cv.imread(file)
    return calHistogram(img)

class Enum(tuple):
    __getattr__ = tuple.index

# Enumerate coins folder
NameFolder = Enum(('Copper', 'Brass', 'Euro1', 'Euro2'))

sample_copper = glob.glob("dataset/Copper/*")
sample_brass = glob.glob("dataset/Brass/*")
sample_euro1 = glob.glob("dataset/1Euro/*")
sample_euro2 = glob.glob("dataset/2Euro/*")

#defining training data and labels
histArray = []
labelArray = []

#looping over the folder and calculate histogram and append to the right class
for i in sample_copper:
    histArray.append(calcHistFromFile(i))
    labelArray.append(NameFolder.Copper)
for i in sample_brass:
    histArray.append(calcHistFromFile(i))
    labelArray.append(NameFolder.Brass)
for i in sample_euro1:
    histArray.append(calcHistFromFile(i))
    labelArray.append(NameFolder.Euro1)
for i in sample_euro2:
    histArray.append(calcHistFromFile(i))
    labelArray.append(NameFolder.Euro2)


#initiate our classifier
ourClassifier = KNeighborsClassifier(n_neighbors=3)

#split dataset
X_train, X_test, y_train, y_test = train_test_split(histArray, labelArray, test_size=.2)

#train and test the classifier
ourClassifier.fit(X_train, y_train)
score = int(ourClassifier.score(X_test, y_test) * 100)
print("Classifier mean accuracy: ", score)

#starting with image segmentation

blurred = cv.GaussianBlur(gray, (7, 7), 0)

circles = cv.HoughCircles(blurred, cv.HOUGH_GRADIENT, dp=2.2, minDist=100, param1=200, param2=100, minRadius=50, maxRadius=120)

def predictFolder(roi):
    hist = calHistogram(roi)

    #predict the folder
    s = ourClassifier.predict([hist])

    return NameFolder[int(s)]

#let's get diameter, folder, and coordinates of each predicted roi
diameter = []
cfolders = []
coordinates = []

count = 0
if circles is not None:
    #getting the radius from the points
    for(x, y, r) in circles[0,:]:
        diameter.append(r)
    circles = np.round(circles[0,:]).astype('int')

    for (x, y, d) in circles:
        count += 1
        coordinates.append((x, y))
        roi = image[y - d: y + d, x - d: x + d]

        m = np.zeros(roi.shape[:2], dtype="uint8")
        w = int(roi.shape[1] / 2)
        h = int(roi.shape[0] / 2)
        cv.circle(m, (w, h), d, (255), -1)

        maskedCoin = cv.bitwise_and(roi, roi, mask=m)
        maskedCoin_resized = cv.resize(maskedCoin, (200, 200))
        cv.imwrite("masked/coin{}.png".format(count), maskedCoin_resized)

        #try to predict
        cfolder = predictFolder(maskedCoin_resized)
        cfolders.append(cfolder)

        #draw contours to show the result
        cv.circle(output, (x, y), d, (0, 255, 0), 2)
        cv.putText(output, cfolder, (x - 40, y), cv.FONT_HERSHEY_PLAIN, 1.5, (0, 255, 0), thickness=2, lineType=cv.LINE_AA)

#get biggest d
biggest = max(diameter)
i = diameter.index(biggest)

#scale everthing according to the big.d
#the proper size: 2€ = 25.75 mm, 1€ 24.25mm
if cfolders[i] == 'Euro2':
    diameter = [x / biggest * 25.75 for x in diameter]
    scaledTO = "Circles are scaled to 2€"
elif cfolders[i] == 'Euro1':
    diameter = [x / biggest * 23.25 for x in diameter]
    scaledTO = "Circles are scaled to 1€"
elif cfolders[i] == 'Brass':
    diameter = [x / biggest * 24.25 for x in diameter]
    scaledTO = "Circles are scaled to 50 cent"
elif cfolders[i] == 'Copper':
    diameter = [x / biggest * 21.25 for x in diameter]
    scaledTO = "Circles are scaled to 5 cent"
else:
    scaledTo = "We cannot scale...."

i = 0
total = 0

while i < len(diameter):
    d = diameter[i]
    folder = cfolders[i]
    (x, y) = coordinates[i]
    t = "?"

    #compare to know the proper diameter

    if math.isclose(d, 25.75, abs_tol=1.25) and folder == "Euro2":
        t = "2 €"
        total += 200
    elif math.isclose(d, 23.25, abs_tol=2.5) and folder == "Euro1":
        t = "1 €"
        total +=100
    elif math.isclose(d, 19.75, abs_tol=1.25) and folder == "Brass":
        t = "10 Cent"
        total += 10
    elif math.isclose(d, 22.25, abs_tol=1.0) and folder == "Brass":
        t = "20 Cent"
        total += 20
    elif math.isclose(d, 24.25, abs_tol=2.5) and folder == "Brass":
        t = "50 Cent"
        total += 50
    elif math.isclose(d, 16.25, abs_tol=1.25) and folder == "Copper":
        t = "1 Cent"
        total += 1
    elif math.isclose(d, 18.75, abs_tol=1.25) and folder == "Copper":
        t = "2 Cent"
        total += 2
    elif math.isclose(d, 21.25, abs_tol=2.5) and folder == "Copper":
        t = "5 Cent"
        total += 5

    cv.putText(output, t, (x - 40, y - 22), cv.FONT_HERSHEY_PLAIN, 1.5, (255, 0, 0), thickness=1, lineType=cv.LINE_AA)
    i+=1

    d = 1024 / output.shape[1]
    dim = (1024, int(output.shape[0] * d))
    image = cv.resize(image, dim, interpolation=cv.INTER_AREA)
    output = cv.resize(output, dim, interpolation=cv.INTER_AREA)

    printMessage = "{} coins detected, the amount is €{:2} \n \n Classifier mean accuracy: {}".format(count, total/100, score)

print(printMessage)
cv.imshow('This is our final image', output)
cv.waitKey(0)
cv.destroyAllWindows()