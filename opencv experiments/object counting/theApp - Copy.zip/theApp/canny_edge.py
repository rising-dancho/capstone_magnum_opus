import cv2 as cv
import numpy as np
from matplotlib import pyplot as plt

theImage = cv.imread('10.JPG')
resized_img = cv.resize(theImage, (600, 400))
rgb_img = cv.cvtColor(resized_img, cv.COLOR_BGR2RGB) #converting to RGB

canny_img = cv.Canny(resized_img, 100, 200)

plt.subplot(121), plt.imshow(rgb_img), plt.title('Original Image')
plt.xticks([]), plt.yticks([])
plt.subplot(122), plt.imshow(canny_img), plt.title('Detected edges')
plt.xticks([]), plt.yticks([])

plt.show()