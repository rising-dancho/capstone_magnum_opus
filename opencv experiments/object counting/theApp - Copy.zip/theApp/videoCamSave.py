import cv2 as cv
import numpy as np

cap = cv.VideoCapture(0)

if (cap.isOpened()) == False:
    print('Unable to read camera feed')

frame_width = int(cap.get(3))
frame_height = int(cap.get(4))

output_vid = cv.VideoWriter('theVideo.avi', cv.VideoWriter_fourcc('M', 'J', 'P', 'G'), 10, (frame_width, frame_height))

while(True):
    ret, frame = cap.read()
    # frame = cv.resize(frame, (600, 600))
    cv.imshow('The name of the window', frame)

    output_vid.write(frame)

    if cv.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
output_vid.release()
cv.destroyAllWindows()