import cv2
import numpy as np
from matplotlib import pyplot as plt

theImg = cv2.imread('IMG_5543.png', 0)
# resized_img = cv2.resize(theImg, (600, 400))

hist = cv2.calcHist([theImg], [0], None, [255], [0, 255])

#Cumulative distribution function
cdf = hist.cumsum()
cvd_normalized = cdf * float(hist.max()) / cdf.max()

plt.plot(cvd_normalized, color='b')
plt.hist(theImg.flatten(), 255, [0, 255], color='r')
plt.xlim([0, 255])
plt.legend(('CDF', 'Histogram'), loc='upper left')

plt.show()

# hist_eq = cv2.equalizeHist(theImg)
# cv2.imshow('Histogram Equalization', hist_eq)
# cv2.waitKey()
# cv2.destroyAllWindows()