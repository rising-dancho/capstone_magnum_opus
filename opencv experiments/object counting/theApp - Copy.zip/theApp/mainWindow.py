import cv2
import numpy as np
from matplotlib import pyplot as plt
import sys
import imutils
from datetime import date, datetime
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
import glob
import math

from PyQt5 import QtWidgets, Qt, QtGui, QtCore
from PyQt5.QtCore import pyqtSignal, pyqtSlot, QThread, QTimer
from PyQt5.QtGui import QPixmap, QImage, QIcon
from PyQt5.QtWidgets import QMessageBox

class MainWindow:
    def __init__(self):
        self.app = QtWidgets.QApplication(sys.argv)
        self.window = QtWidgets.QMainWindow()

        mycss = 'layout.css'
        with open(mycss, 'r') as fh:
            self.app.setStyleSheet(fh.read())

        self.initGui()

        self.window.setWindowTitle('The App for you')
        self.window.setGeometry(300, 100, 815, 1000)
        self.window.setWindowIcon(QIcon('usrprof.png'))
        self.window.setMaximumSize(815, 1000)

        self.window.show()
        sys.exit(self.app.exec_())

    def initGui(self):
        self.createMenu()
        self.createToolbar()
        self.createStatusBar()
        self.createBoxLayout()

    def createMenu(self):
        menuBar = self.window.menuBar()
        menuBar.setNativeMenuBar(False)

        fileMenu = menuBar.addMenu('File')
        editMenu = menuBar.addMenu('Edit')
        videoMenu = menuBar.addMenu('Video')
        functionMenu = menuBar.addMenu('Functions')

        openMenu = QtWidgets.QAction("📂 Open Image", self.window)
        openMenu.setShortcut('CTRL+O')
        openMenu.setStatusTip('Open a file')

        undoOp = QtWidgets.QAction('Undo', self.window)
        undoOp.setShortcut('CTRL+Z')
        undoOp.triggered.connect(self.editTexts)

        copyOp = QtWidgets.QAction('Copy', self.window)
        copyOp.setShortcut('CTRL+C')
        copyOp.triggered.connect(self.copyText)

        pasteOp = QtWidgets.QAction('Paste', self.window)
        pasteOp.setShortcut('CTRL+V')
        pasteOp.triggered.connect(self.pasteText)

        quitMenu = QtWidgets.QAction('Quit', self.window)
        quitMenu.setStatusTip('Leave the application')
        quitMenu.setShortcut('CTRL+Q')
        quitMenu.triggered.connect(self.exitApp)

        drawLine = QtWidgets.QAction('Draw Line', self.window)
        drawLine.triggered.connect(self.drawOurline)

        drawCircle = QtWidgets.QAction('Draw Circle', self.window)

        blurredImg = QtWidgets.QAction('Blur Image', self.window)
        blurredImg.triggered.connect(self.blurImg)

        # associate menus to the fileMenu
        fileMenu.addAction(openMenu)
        fileMenu.addSeparator()
        fileMenu.addAction(quitMenu)

        # associate menys to editMenu
        editMenu.addAction(undoOp)
        editMenu.addSeparator()
        editMenu.addAction(copyOp)
        editMenu.addAction(pasteOp)

        # associate menu to functions menu
        drawingShapes = functionMenu.addMenu('Drawing Shapes')
        functionMenu.addSeparator()
        functionMenu.addAction(blurredImg)

        # associate menus to drawingShapes
        drawingShapes.addAction(drawLine)
        drawingShapes.addAction(drawCircle)


    def createToolbar(self):
        toolbar1 = self.window.addToolBar('first')
        toolbar1.setMovable(False)

        openFile = QtWidgets.QAction('📂 Open', self.window)
        openFile.triggered.connect(self.openDialogFile)
        startWebcam = QtWidgets.QAction('📹 Start Webcam', self.window)

        self.recognizing = QtWidgets.QAction('Count your coins', self.window)
        self.recognizing.setDisabled(True)
        self.recognizing.triggered.connect(self.recognition)

        #Associate to toolbar
        toolbar1.addAction(openFile)
        toolbar1.addSeparator()
        toolbar1.addAction(startWebcam)
        toolbar1.addSeparator()
        toolbar1.addAction(self.recognizing)


    def createStatusBar(self):
        mydate = date.today()
        mytime = datetime.now().strftime('%H:%M:%S')
        msg = 'Ready... 🗓 Yes 🕓 The time here'
        self.window.statusBar().showMessage(msg)


    def createBoxLayout(self):
        self.imgLabel = QtWidgets.QLabel(self.window)
        self.imgLabel.setGeometry(0, 73, 600, 607)
        self.imgLabel.setObjectName('imlab')
        self.imgLabel.setText('Add image or start web cam to begin')
        self.imgLabel.setWordWrap(True)
        self.imgLabel.setAlignment(QtCore.Qt.AlignCenter)
        self.imgLabel.setScaledContents(True)

        self.optlabel = QtWidgets.QLabel(self.window)
        self.optlabel.setGeometry(600, 73, 215, 607)
        self.optlabel.setObjectName('optlab')
        self.optlabel.setText(' 👋 Welcome')
        self.optlabel.setWordWrap(True)
        self.optlabel.setAlignment(QtCore.Qt.AlignCenter)


    def exitApp(self):
        myQuestion = QMessageBox
        result = myQuestion.question(self.window, 'Quit App?', 'Do you really want to quit??', myQuestion.Yes | myQuestion.No)
        if result == myQuestion.Yes:
            QtWidgets.qApp.quit()
        else:
            print('The user says NO')

    def openDialogFile(self):
        filename = QtWidgets.QFileDialog.getOpenFileName()
        self.path = filename[0]

        if self.path:
            myPixmap = QtGui.QPixmap(self.path)
            self.imgLabel.setPixmap(myPixmap)
            msgStatus = "Image: {} loaded".format(self.path)
            self.window.statusBar().showMessage(msgStatus)
            self.recognizing.setDisabled(False)

            return self.path

    def recognition(self):
        imgPath = self.path
        image = cv2.imread(imgPath)
        d = 1024 / image.shape[1]
        dim = (1024, int(image.shape[0] * d))
        image = cv2.resize(image, dim, interpolation=cv2.INTER_AREA)

        output = image.copy()

        # convert the image to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        gray = clahe.apply(gray)

        # calculate the histogram
        def calHistogram(img):
            m = np.zeros(img.shape[:2], dtype="uint8")
            (w, h) = (int(img.shape[1] / 2), int(img.shape[0] / 2))
            cv2.circle(m, (w, h), 60, 255, -1)

            h = cv2.calcHist([img], [0, 1, 2], m, [8, 8, 8], [0, 256, 0, 256, 0, 256])

            return cv2.normalize(h, h).flatten()

        def calcHistFromFile(file):
            img = cv2.imread(file)
            return calHistogram(img)

        class Enum(tuple):
            __getattr__ = tuple.index

        # Enumerate coins folder
        NameFolder = Enum(('Copper', 'Brass', 'Euro1', 'Euro2'))

        sample_copper = glob.glob("dataset/Copper/*")
        sample_brass = glob.glob("dataset/Brass/*")
        sample_euro1 = glob.glob("dataset/1Euro/*")
        sample_euro2 = glob.glob("dataset/2Euro/*")

        # defining training data and labels
        histArray = []
        labelArray = []

        # looping over the folder and calculate histogram and append to the right class
        for i in sample_copper:
            histArray.append(calcHistFromFile(i))
            labelArray.append(NameFolder.Copper)
        for i in sample_brass:
            histArray.append(calcHistFromFile(i))
            labelArray.append(NameFolder.Brass)
        for i in sample_euro1:
            histArray.append(calcHistFromFile(i))
            labelArray.append(NameFolder.Euro1)
        for i in sample_euro2:
            histArray.append(calcHistFromFile(i))
            labelArray.append(NameFolder.Euro2)

        # initiate our classifier
        ourClassifier = KNeighborsClassifier(n_neighbors=3)

        # split dataset
        X_train, X_test, y_train, y_test = train_test_split(histArray, labelArray, test_size=.2)

        # train and test the classifier
        ourClassifier.fit(X_train, y_train)
        score = int(ourClassifier.score(X_test, y_test) * 100)
        print("Classifier mean accuracy: ", score)

        # starting with image segmentation

        blurred = cv2.GaussianBlur(gray, (7, 7), 0)

        circles = cv2.HoughCircles(blurred, cv2.HOUGH_GRADIENT, dp=2.2, minDist=100, param1=200, param2=100, minRadius=50,
                                  maxRadius=120)

        def predictFolder(roi):
            hist = calHistogram(roi)

            # predict the folder
            s = ourClassifier.predict([hist])

            return NameFolder[int(s)]

        # let's get diameter, folder, and coordinates of each predicted roi
        diameter = []
        cfolders = []
        coordinates = []

        count = 0
        if circles is not None:
            # getting the radius from the points
            for (x, y, r) in circles[0, :]:
                diameter.append(r)
            circles = np.round(circles[0, :]).astype('int')

            for (x, y, d) in circles:
                count += 1
                coordinates.append((x, y))
                roi = image[y - d: y + d, x - d: x + d]

                m = np.zeros(roi.shape[:2], dtype="uint8")
                w = int(roi.shape[1] / 2)
                h = int(roi.shape[0] / 2)
                cv2.circle(m, (w, h), d, (255), -1)

                maskedCoin = cv2.bitwise_and(roi, roi, mask=m)
                maskedCoin_resized = cv2.resize(maskedCoin, (200, 200))
                cv2.imwrite("masked/coin{}.png".format(count), maskedCoin_resized)

                # try to predict
                cfolder = predictFolder(maskedCoin_resized)
                cfolders.append(cfolder)

                # draw contours to show the result
                cv2.circle(output, (x, y), d, (0, 255, 0), 2)
                cv2.putText(output, cfolder, (x - 40, y), cv2.FONT_HERSHEY_PLAIN, 1.5, (0, 255, 0), thickness=2,
                           lineType=cv2.LINE_AA)

        # get biggest d
        biggest = max(diameter)
        i = diameter.index(biggest)

        # scale everthing according to the big.d
        # the proper size: 2€ = 25.75 mm, 1€ 24.25mm
        if cfolders[i] == 'Euro2':
            diameter = [x / biggest * 25.75 for x in diameter]
            scaledTO = "Circles are scaled to 2€"
        elif cfolders[i] == 'Euro1':
            diameter = [x / biggest * 23.25 for x in diameter]
            scaledTO = "Circles are scaled to 1€"
        elif cfolders[i] == 'Brass':
            diameter = [x / biggest * 24.25 for x in diameter]
            scaledTO = "Circles are scaled to 50 cent"
        elif cfolders[i] == 'Copper':
            diameter = [x / biggest * 21.25 for x in diameter]
            scaledTO = "Circles are scaled to 5 cent"
        else:
            scaledTo = "We cannot scale...."

        i = 0
        total = 0

        while i < len(diameter):
            d = diameter[i]
            folder = cfolders[i]
            (x, y) = coordinates[i]
            t = "?"

            # compare to know the proper diameter

            if math.isclose(d, 25.75, abs_tol=1.25) and folder == "Euro2":
                t = "2 €"
                total += 200
            elif math.isclose(d, 23.25, abs_tol=2.5) and folder == "Euro1":
                t = "1 €"
                total += 100
            elif math.isclose(d, 19.75, abs_tol=1.25) and folder == "Brass":
                t = "10 Cent"
                total += 10
            elif math.isclose(d, 22.25, abs_tol=1.0) and folder == "Brass":
                t = "20 Cent"
                total += 20
            elif math.isclose(d, 24.25, abs_tol=2.5) and folder == "Brass":
                t = "50 Cent"
                total += 50
            elif math.isclose(d, 16.25, abs_tol=1.25) and folder == "Copper":
                t = "1 Cent"
                total += 1
            elif math.isclose(d, 18.75, abs_tol=1.25) and folder == "Copper":
                t = "2 Cent"
                total += 2
            elif math.isclose(d, 21.25, abs_tol=2.5) and folder == "Copper":
                t = "5 Cent"
                total += 5

            cv2.putText(output, t, (x - 40, y - 22), cv2.FONT_HERSHEY_PLAIN, 1.5, (255, 0, 0), thickness=1,
                       lineType=cv2.LINE_AA)
            i += 1

            d = 1024 / output.shape[1]
            dim = (1024, int(output.shape[0] * d))
            image = cv2.resize(image, dim, interpolation=cv2.INTER_AREA)
            output = cv2.resize(output, dim, interpolation=cv2.INTER_AREA)

            printMessage = "{} coins detected, the amount is €{:2} \n \n Classifier mean accuracy: {}".format(count,
                                                                                                              total / 100,
                                                                                                              score)
        showImg = QtGui.QImage(output.data, output.shape[1], output.shape[0], output.shape[1] * 3,
                               QtGui.QImage.Format_RGB888).rgbSwapped()
        self.imgLabel.setPixmap(QPixmap.fromImage(showImg))
        self.optlabel.setText(printMessage)

    def drawOurline(self):
        imgPath = self.path
        theImg = cv2.imread(imgPath)
        newImg = cv2.line(theImg, (0, 50), (230, 350), (200, 50, 50), 4)
        showImg = QtGui.QImage(newImg.data, newImg.shape[1], newImg.shape[0], newImg.shape[1] * 3, QtGui.QImage.Format_RGB888).rgbSwapped()
        self.imgLabel.setPixmap(QPixmap.fromImage(showImg))

    def blurImg(self):
        imgPath = self.path
        theImg = cv2.imread(imgPath, cv2.IMREAD_COLOR)
        newImg = cv2.blur(theImg, (5, 5))  # kernel value
        showImg = QtGui.QImage(newImg.data, newImg.shape[1], newImg.shape[0], newImg.shape[1] * 3,
                               QtGui.QImage.Format_RGB888).rgbSwapped()
        self.imgLabel.setPixmap(QPixmap.fromImage(showImg))
        self.optlabel.setText('Blurred Image with (5, 5) kernel')

    def editTexts(self):
        self.imgLabel.setText('The edit menu works')
        self.optlabel.setText('Let us move on')

    def copyText(self):
        imagePath = self.path
        self.imgLabel.setText(imagePath)

    def pasteText(self):
        QMessageBox.about(self.window, "About", "This application is built by ..... version 3.2.1")


main = MainWindow()