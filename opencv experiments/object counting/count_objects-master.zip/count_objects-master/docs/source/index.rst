.. Count Objects documentation master file, created by
   sphinx-quickstart on Fri Oct 04 13:46:34 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Count Objects's documentation!
=========================================

Contents:

.. toctree::
   :maxdepth: 2
   
   introduction
   tutorial
   
.. automodule:: contour_features
   :members:
   
.. automodule:: im_proc
   :members:



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

